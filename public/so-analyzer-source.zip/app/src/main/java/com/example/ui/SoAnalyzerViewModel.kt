package com.example.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.elf.ElfHeaderExtractor
import com.example.elf.ElfParser
import com.example.model.ElfInfo
import com.example.sample.SampleSoGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream

sealed interface AnalyzerUiState {
  data object Idle : AnalyzerUiState
  data class Loading(val message: String) : AnalyzerUiState
  data class Success(
    val report: ElfInfo,
    val binutilsResult: ElfHeaderExtractor.ExtractionResult
  ) : AnalyzerUiState
  data class Error(val message: String, val details: String? = null) : AnalyzerUiState
}

enum class AnalyzerTab(val title: String) {
  OVERVIEW("Overview"),
  ELF_HEADERS("ELF Headers (readelf)"),
  DEPENDENCIES_JNI("Dependencies & JNI"),
  SYMBOLS("Symbols"),
  SECTIONS("Sections"),
  STRINGS("Strings"),
  APK_INSTALL("Install APK")
}

enum class SymbolFilter(val label: String) {
  ALL("All"),
  JNI_ONLY("JNI Only"),
  EXPORTED("Exported"),
  IMPORTED("Imported")
}

class SoAnalyzerViewModel : ViewModel() {

  private val _uiState = MutableStateFlow<AnalyzerUiState>(AnalyzerUiState.Idle)
  val uiState: StateFlow<AnalyzerUiState> = _uiState.asStateFlow()

  private val _selectedTab = MutableStateFlow(AnalyzerTab.OVERVIEW)
  val selectedTab: StateFlow<AnalyzerTab> = _selectedTab.asStateFlow()

  private val _symbolSearchQuery = MutableStateFlow("")
  val symbolSearchQuery: StateFlow<String> = _symbolSearchQuery.asStateFlow()

  private val _symbolFilter = MutableStateFlow(SymbolFilter.ALL)
  val symbolFilter: StateFlow<SymbolFilter> = _symbolFilter.asStateFlow()

  private val _stringSearchQuery = MutableStateFlow("")
  val stringSearchQuery: StateFlow<String> = _stringSearchQuery.asStateFlow()

  private val _stringCategoryFilter = MutableStateFlow("All")
  val stringCategoryFilter: StateFlow<String> = _stringCategoryFilter.asStateFlow()

  fun setTab(tab: AnalyzerTab) {
    _selectedTab.value = tab
  }

  fun setSymbolSearch(query: String) {
    _symbolSearchQuery.value = query
  }

  fun setSymbolFilter(filter: SymbolFilter) {
    _symbolFilter.value = filter
  }

  fun setStringSearch(query: String) {
    _stringSearchQuery.value = query
  }

  fun setStringCategoryFilter(cat: String) {
    _stringCategoryFilter.value = cat
  }

  fun reset() {
    _uiState.value = AnalyzerUiState.Idle
    _selectedTab.value = AnalyzerTab.OVERVIEW
    _symbolSearchQuery.value = ""
    _stringSearchQuery.value = ""
  }

  fun loadSample() {
    viewModelScope.launch {
      _uiState.value = AnalyzerUiState.Loading("Generating and analyzing sample ELF64 library...")
      try {
        val bytes = withContext(Dispatchers.Default) {
          SampleSoGenerator.createSampleLibrary()
        }
        val report = withContext(Dispatchers.Default) {
          ElfParser.parse(bytes, "libnative-lib.so")
        }
        val binutilsResult = withContext(Dispatchers.Default) {
          ElfHeaderExtractor().extract(bytes)
        }
        _uiState.value = AnalyzerUiState.Success(report, binutilsResult)
        _selectedTab.value = AnalyzerTab.OVERVIEW
      } catch (e: Exception) {
        _uiState.value = AnalyzerUiState.Error("Failed to parse sample library: ${e.message}", e.stackTraceToString())
      }
    }
  }

  fun analyzeUri(context: Context, uri: Uri) {
    viewModelScope.launch {
      _uiState.value = AnalyzerUiState.Loading("Reading file...")
      try {
        val (fileName, bytes) = withContext(Dispatchers.IO) {
          var name = "unknown.so"
          context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex != -1 && cursor.moveToFirst()) {
              name = cursor.getString(nameIndex) ?: "library.so"
            }
          }

          val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
          if (inputStream == null) {
            throw IllegalArgumentException("Unable to open input stream for the selected file.")
          }

          val buffer = ByteArrayOutputStream()
          val data = ByteArray(16384)
          var nRead: Int
          var totalBytes = 0L
          val maxAllowedBytes = 80 * 1024 * 1024L // 80 MB limit to prevent out-of-memory on mobile devices

          inputStream.use { stream ->
            while (stream.read(data, 0, data.size).also { nRead = it } != -1) {
              totalBytes += nRead
              if (totalBytes > maxAllowedBytes) {
                throw IllegalArgumentException("File exceeds the maximum analysis size limit of 80 MB.")
              }
              buffer.write(data, 0, nRead)
            }
          }

          Pair(name, buffer.toByteArray())
        }

        _uiState.value = AnalyzerUiState.Loading("Parsing ELF headers, dynamic symbols & sections...")
        val report = withContext(Dispatchers.Default) {
          ElfParser.parse(bytes, fileName)
        }
        val binutilsResult = withContext(Dispatchers.Default) {
          ElfHeaderExtractor().extract(bytes)
        }
        _uiState.value = AnalyzerUiState.Success(report, binutilsResult)
        _selectedTab.value = AnalyzerTab.OVERVIEW
      } catch (e: Exception) {
        _uiState.value = AnalyzerUiState.Error(
          message = e.message ?: "An unexpected error occurred while parsing the .so file.",
          details = e.stackTraceToString()
        )
      }
    }
  }

  fun getShareableReportText(report: ElfInfo): String {
    return buildString {
      appendLine("=========================================")
      appendLine("  SO ANALYZER - NATIVE BINARY REPORT")
      appendLine("=========================================")
      appendLine("File Name: ${report.fileName}")
      appendLine("File Size: ${report.fileSizeFormatted}")
      appendLine("Architecture: ${report.machine}")
      appendLine("ABI Name: ${report.abiName}")
      appendLine("Class: ${if (report.is64Bit) "64-bit ELF (ELF64)" else "32-bit ELF (ELF32)"}")
      appendLine("Endianness: ${report.endianness}")
      appendLine("Type: ${report.fileType}")
      appendLine("Entry Point: ${report.entryPointHex}")
      appendLine("SONAME: ${report.soname ?: "Not specified"}")
      appendLine()
      appendLine("--- CHECKSUMS ---")
      appendLine("MD5:    ${report.md5}")
      appendLine("SHA-1:  ${report.sha1}")
      appendLine("SHA-256: ${report.sha256}")
      appendLine()
      appendLine("--- SECURITY AUDIT ---")
      appendLine("Verdict: ${report.securityReport.overallVerdict}")
      appendLine("• PIE: ${report.securityReport.pieStatus.name} [${report.securityReport.pieStatus.status}]")
      appendLine("• NX Stack: ${report.securityReport.nxStatus.name} [${report.securityReport.nxStatus.status}]")
      appendLine("• RELRO: ${report.securityReport.relroStatus.name} [${report.securityReport.relroStatus.status}]")
      appendLine("• Stack Canary: ${report.securityReport.canaryStatus.name} [${report.securityReport.canaryStatus.status}]")
      appendLine("• Symbol Stripping: ${report.securityReport.strippedStatus.name} [${report.securityReport.strippedStatus.status}]")
      appendLine()
      appendLine("--- LINKED DEPENDENCIES (DT_NEEDED) ---")
      if (report.dependencies.isEmpty()) {
        appendLine("None detected.")
      } else {
        report.dependencies.forEach { appendLine("• $it") }
      }
      appendLine()
      appendLine("--- JNI EXPORTED FUNCTIONS (${report.jniFunctions.size}) ---")
      if (report.jniFunctions.isEmpty()) {
        appendLine("No JNI functions found.")
      } else {
        report.jniFunctions.forEach { jni ->
          appendLine("• ${jni.fullSignature} [${jni.rawSymbol}]")
        }
      }
      appendLine()
      appendLine("--- COMPATIBILITY ---")
      appendLine(report.compatibilitySummary)
      appendLine("=========================================")
    }
  }
}
